This is the README file for A0110649J's submission

== General Notes about this assignment ==

Main submission file: 

index.py : indexer, builds dic and postings (regex split then porter stemmer indexing)
search.py : performs tf idf search, returns top 10 searches

== Files included with this submission ==

ESSAY.txt
	- txt file containing answers to the questions
README.txt
	- this file
	
== Statement of individual work ==

Please initial one of the following statements.

[X] I, A0110649J, certify that I have followed the CS 3245 Information
Retrieval class guidelines for homework assignments.  In particular, I
expressly vow that I have followed the Facebook rule in discussing
with others in doing the assignment and did not take notes (digital or
printed) from the discussions.  

== References ==
stackoverflow, google (python syntax and data structure help)
email address: A0110649J@u.nus.edu
